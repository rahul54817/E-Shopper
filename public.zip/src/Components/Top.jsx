import React from 'react'

const Top = () => {
  return (
    <div>
          <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>

    </div>
  )
}

export default Top
