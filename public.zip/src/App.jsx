import React from 'react'
import {BrowserRouter as Router , Routes, Route} from 'react-router-dom'
import TopBar from './Components/TopBar'
import Contact from './Pages/Contact'
import ShopingCart from './Pages/ShopingCart'
import Registration from './Pages/Registration'
import Home from './Pages/Home'

const App = () => {
  return (
    <>
        
    </>
  )
}

export default App
